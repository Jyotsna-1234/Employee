package org.com.capg.healthcare.exception;

public class UseralreadyExistException extends Exception{

	public UseralreadyExistException(String msg) {
		super(msg);
	}
}