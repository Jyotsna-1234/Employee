package org.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCareManagement2Application {

	public static void main(String[] args) {
		SpringApplication.run(HealthCareManagement2Application.class, args);
	}
	
	
	

}
